public class Element<E> {

    private Element<E> next = null;
    private E element;
    private Element<E> parent = null;
    private boolean exists = true;
    private int id = 0;
    private static int num = 0;

    // Represents the front of the List
    public Element(E element) {
        this.element = element;
        id = num;
        num++;
        next = new Element<>();
        parent = new Element<>();
    }

    // Any old element in the list
    public Element(E e, Element<E> parent) {
        this.element = e;
        this.parent = parent;
        id = num;
        num++;
        next = new Element<>();
    }

    // Empty element used only when an element must be created but does not actually represent anything, e.g. when a return value is needed
    public Element() {
        exists = false;
        next = new Element<E>(false);
        parent = next;
    }

    private Element(boolean exists) {
        this.exists = false;
    }

    public void setNext(Element<E> next) {
        this.next = next;
    }

    public Element<E> getNext() {
        return next;
    }

    public void setElement(E element) {
        this.element = element;
    }

    public E getElement() {
        return element;
    }

    public void setParent(Element<E> parent) {
        this.parent = parent;
    }

    public Element<E> getParent() {
        return parent;
    }

    public boolean isExists() {
        if(element == null)
            return false;
        return exists;
    }

    public int getId() {
        return id;
    }
}