public class Main {

	public static void main(String args[]) {

		BSBaum b = new BSBaum();
		b.add(new Integer(5));
		b.add(new Integer(3));
		b.add(new Integer(2));
		b.add(new Integer(8));
		b.add(new Integer(7));
		b.add(new Integer(4));
		b.delete(new Integer(8));
		b.add(new Integer(6));
		b.add(new Integer(1));
		b.printInorder();
		//System.out.println(b.delete(2));
	}
}
